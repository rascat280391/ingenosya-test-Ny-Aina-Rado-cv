import { Candidat } from './candidat';

describe('Candidat', () => {
  it('should create an instance', () => {
    expect(new Candidat()).toBeTruthy();
  });
});
